# SamFlasher-Tool
A Simple tool to flash into samsung devices.
Formats accepted: .tar
 
## Linux Installation
Tested on ZorinOS 16.1 and Arch Linux

`git clone https://github.com/KreitinnSoftware/SamFlasher-Tool.git`

`cd SamFlasher-Tool`

`sh install.sh`

Made by @Kreitinn
Thx for @Ttheuxs for helping

